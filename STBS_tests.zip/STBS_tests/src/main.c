#include <zephyr/kernel.h>
#include "../../stbs.h"

LOG_MODULE_REGISTER(STBS_MAIN);

// Threads
void thread0(void)
{
	while (1) {
		LOG_INF("Hello, I am thread0\n");
		k_sleep(K_FOREVER);
	}
}

void thread1(void)
{
	while (1) {
		LOG_INF("Hello, I am thread1\n");
		k_sleep(K_FOREVER);
	}
}

K_THREAD_DEFINE(thread0_id, STACKSIZE, thread0, NULL, NULL, NULL, 6, 0, 0);
K_THREAD_DEFINE(thread1_id, STACKSIZE, thread1, NULL, NULL, NULL, 7, 0, 0);

int main(void)
{
        STBS* scheduler = k_malloc(sizeof(STBS));
        STBS_Init(scheduler, 50, 8);
        Task* t0 = k_malloc(sizeof(Task));
        Task* t1 = k_malloc(sizeof(Task));
        Create_Task(t0, 50, 6, "task 0", thread0_id);
        Create_Task(t1, 75, 7, "task 1", thread1_id);
        STBS_AddTask(scheduler, t0);
        STBS_AddTask(scheduler, t1);
        STBS_Start(scheduler);

        k_msleep(10000);
        STBS_print(scheduler);
        STBS_printTaskByID(scheduler, "task 1");

        STBS_Stop(scheduler);
        
        return 0;
}

