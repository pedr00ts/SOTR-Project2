#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/sys/printk.h>
#include <string.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/logging/log.h>

#include "../../stbs.h"
#include "../../leds.h"
#include "../../uart_comm.h"

#define STACKSIZE 1024
#define THREAD_PRIORITY 7

#define BUTTON0_NODE DT_ALIAS(sw0)
#define BUTTON1_NODE DT_ALIAS(sw1)
#define BUTTON2_NODE DT_ALIAS(sw2)
#define BUTTON3_NODE DT_ALIAS(sw3)

// Verificar se o node existe no DeviceTree
#if !DT_NODE_HAS_STATUS(BUTTON0_NODE, okay) || \
    !DT_NODE_HAS_STATUS(BUTTON1_NODE, okay) || \
    !DT_NODE_HAS_STATUS(BUTTON2_NODE, okay) || \
    !DT_NODE_HAS_STATUS(BUTTON3_NODE, okay)
#error "Unsupported board: button devicetree aliases are not defined"
#endif

// GPIO dev and pin configuration
static const struct gpio_dt_spec button0 = GPIO_DT_SPEC_GET_OR(BUTTON0_NODE, gpios, {0});
static const struct gpio_dt_spec button1 = GPIO_DT_SPEC_GET_OR(BUTTON1_NODE, gpios, {0});
static const struct gpio_dt_spec button2 = GPIO_DT_SPEC_GET_OR(BUTTON2_NODE, gpios, {0});
static const struct gpio_dt_spec button3 = GPIO_DT_SPEC_GET_OR(BUTTON3_NODE, gpios, {0});

LOG_MODULE_REGISTER(button_control);

// UART device definition
const struct device *uart_dev = DEVICE_DT_GET(DT_NODELABEL(uart0));

// RTDB structure definition
typedef struct {
    uint8_t inputs[4];  // Valores dos botões
    uint8_t outputs[4]; // Valores dos LEDs
} RTDB;

RTDB rtdb;

if (!device_is_ready(uart_dev)) {
    LOG_ERR("UART device not ready\n");
    return -1;
}


// Mutex for RTDB access
K_MUTEX_DEFINE(test_mutex);

K_THREAD_DEFINE(thread0_id, STACKSIZE, thread_uart, NULL, NULL, NULL, THREAD_PRIORITY, 0, 0);
K_THREAD_DEFINE(thread1_id, STACKSIZE, thread_leds, NULL, NULL, NULL, THREAD_PRIORITY, 0, 0);
K_THREAD_DEFINE(thread2_id, STACKSIZE, thread_buttons, NULL, NULL, NULL, THREAD_PRIORITY, 0, 0);

// Initialize RTDB
memset(&rtdb, 0, sizeof(RTDB));


// TASK THREADS
void thread_uart(void)
{
	while (1) {
		k_sleep(K_FOREVER);
                
        // Construir o frame UART para informar sobre a ativação da tarefa
        char frame[50];
        build_uart_frame(frame, 'M', 'A', current_task->task_id);
        send_uart_message(frame);
	}
}

// Thread LEDS -> periodicamente checa o estado da RTDB e atualiza os LEDs
void thread_leds(void)
{
	while (1) {
		k_sleep(K_FOREVER);
	}
}

// Thread buttons -> Checa o estado dos botões e atualiza a RTDB
void thread_buttons(void)
{
	while (1) {
		k_sleep(K_FOREVER);
	}
}

// Initialize the buttons
void buttons_init() {
    if (!device_is_ready(button0.port) ||
        !device_is_ready(button1.port) ||
        !device_is_ready(button2.port) ||
        !device_is_ready(button3.port)) {
        LOG_ERR("GPIO device is not ready\n");
        return;
    }

    gpio_pin_configure_dt(&button0, GPIO_INPUT | GPIO_PULL_UP);
    gpio_pin_configure_dt(&button1, GPIO_INPUT | GPIO_PULL_UP);
    gpio_pin_configure_dt(&button2, GPIO_INPUT | GPIO_PULL_UP);
    gpio_pin_configure_dt(&button3, GPIO_INPUT | GPIO_PULL_UP);

    LOG_INF("Buttons have been initialized successfully\n");
}

// Função para atualizar o estado das entradas digitais (botões)
// TODO: Usar na thread de botões
void update_inputs() {
    // Supondo que temos uma função fictícia para ler os botões
    for (int i = 0; i < 4; i++) {
        rtdb.inputs[i] = read_button_state(i);  // Substituir por uma função real de leitura
    }
}

uint8_t read_button_state(int button_index) {
    int state = 0;
    switch (button_index) {
        case 0:
            state = gpio_pin_get_dt(&button0);
            break;
        case 1:
            state = gpio_pin_get_dt(&button1);
            break;
        case 2:
            state = gpio_pin_get_dt(&button2);
            break;
        case 3:
            state = gpio_pin_get_dt(&button3);
            break;
        default:
            LOG_ERR("Invalid button index: %d\n", button_index);
            return 0;
    }

    return (state == 0) ? 1 : 0;  // 1 para pressionado, 0 para não pressionado (assumindo pull-up)
}
