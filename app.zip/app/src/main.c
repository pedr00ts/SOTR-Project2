#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/logging/log.h>
#include "../../stbs.h"
#include "../../leds.h"
#include "../../uart_comm.h"

#define STACKSIZE 4096
#define THREAD_PRIORITY 7

#define BUTTON0_NODE DT_ALIAS(sw0)
#define BUTTON1_NODE DT_ALIAS(sw1)
#define BUTTON2_NODE DT_ALIAS(sw2)
#define BUTTON3_NODE DT_ALIAS(sw3)

// GPIO configuration for buttons
static const struct gpio_dt_spec button0 = GPIO_DT_SPEC_GET_OR(DT_ALIAS(sw0), gpios, {0});
static const struct gpio_dt_spec button1 = GPIO_DT_SPEC_GET_OR(DT_ALIAS(sw1), gpios, {0});
static const struct gpio_dt_spec button2 = GPIO_DT_SPEC_GET_OR(DT_ALIAS(sw2), gpios, {0});
static const struct gpio_dt_spec button3 = GPIO_DT_SPEC_GET_OR(DT_ALIAS(sw3), gpios, {0});

LOG_MODULE_REGISTER(LOG_MAIN);

// RTDB structure definition
typedef struct {
    uint8_t inputs[4];  // Button states
    uint8_t outputs[4]; // LED states
} RTDB;

// Global variables
STBS *scheduler;
static RTDB rtdb = {0};
K_MUTEX_DEFINE(rtdb_mutex);

// Function prototypes
void buttons_init(void);
uint8_t read_button_state(int button_index);
void thread_uart(void);
void thread_leds(void);
void thread_buttons(void);

// TASK THREADS
void thread_uart(void) {
    while (1) {
        // UART thread functionality to be added later
        k_sleep(K_FOREVER);
    }
}

void thread_leds(void) {
    k_sleep(K_FOREVER);
    leds_init(); // Initialize LEDs
    LOG_INF("thread_leds starting\n");
    while (1) {
        k_mutex_lock(&rtdb_mutex, K_FOREVER);
        for (int i = 0; i < 4; i++) {
            __ASSERT(i >= 0 && i < 4, "Index out of bounds: %d", i);
            rtdb.outputs[i] = rtdb.inputs[i]; // Map button states to LEDs
            LOG_INF("output %d: %d\n", i, rtdb.outputs[i]);
        }
        update_outputs(); // Update LEDs based on RTDB outputs
        k_mutex_unlock(&rtdb_mutex);
        k_sleep(K_FOREVER);
    }
}

void thread_buttons(void) {
    k_sleep(K_FOREVER);
    buttons_init(); // Initialize buttons
    LOG_INF("thread_buttons starting\n");
    while (1) {
        k_mutex_lock(&rtdb_mutex, K_FOREVER);
        for (int i = 0; i < 4; i++) {
            __ASSERT(i >= 0 && i < 4, "Index out of bounds: %d", i);
            rtdb.inputs[i] = read_button_state(i); // Update RTDB inputs with button states
            LOG_INF("input %d: %d\n", i, rtdb.inputs[i]);
        }
        k_mutex_unlock(&rtdb_mutex);
        k_sleep(K_FOREVER);
    }
}

void buttons_init(void) {
    if (!device_is_ready(button0.port) ||
        !device_is_ready(button1.port) ||
        !device_is_ready(button2.port) ||
        !device_is_ready(button3.port)) {
        LOG_ERR("GPIO device is not ready for buttons\n");
        return;
    }

    gpio_pin_configure_dt(&button0, GPIO_INPUT | GPIO_PULL_UP);
    gpio_pin_configure_dt(&button1, GPIO_INPUT | GPIO_PULL_UP);
    gpio_pin_configure_dt(&button2, GPIO_INPUT | GPIO_PULL_UP);
    gpio_pin_configure_dt(&button3, GPIO_INPUT | GPIO_PULL_UP);

    LOG_INF("Buttons have been initialized successfully\n");
}

// Atualizar os LEDs com base no RTDB
void update_outputs(void) {
    // Atualiza cada LED com o valor armazenado no RTDB
    for (int i = 0; i < 4; i++) {
        set_led_state(i, rtdb.outputs[i]);
    }
}

uint8_t read_button_state(int button_index) {
    uint8_t state = 0;
    switch (button_index) {
        case 0:
            state = gpio_pin_get_dt(&button0);
            break;
        case 1:
            state = gpio_pin_get_dt(&button1);
            break;
        case 2:
            state = gpio_pin_get_dt(&button2);
            break;
        case 3:
            state = gpio_pin_get_dt(&button3);
            break;
        default:
            LOG_ERR("Invalid button index: %d\n", button_index);
            return 0;
    }
    return (state == 0) ? 1 : 0; // Return 1 for pressed, 0 for not pressed
}

//K_THREAD_DEFINE(thread_uart_id, STACKSIZE, thread_uart, NULL, NULL, NULL, THREAD_PRIORITY, 0, 0);
K_THREAD_DEFINE(thread_leds_id, STACKSIZE, thread_leds, NULL, NULL, NULL, THREAD_PRIORITY, 0, 0);
K_THREAD_DEFINE(thread_buttons_id, STACKSIZE, thread_buttons, NULL, NULL, NULL, THREAD_PRIORITY, 0, 0);

int main(void) {
    LOG_INF("Starting system\n");

    // Allocate memory for scheduler and RTDB
    scheduler = k_malloc(sizeof(STBS));
    if (!scheduler) {
        LOG_ERR("Failed to allocate memory for scheduler\n");
        return -1;
    }

  /*   rtdb = k_malloc(sizeof(RTDB));
    if (!rtdb) {
        LOG_ERR("Failed to allocate memory for RTDB\n");
        return -1;
    } */

    // memset(rtdb, 0, sizeof(RTDB)); // Initialize RTDB

    // Initialize and start the scheduler
    STBS_Init(scheduler, 50, 8);

    Task *t_leds __aligned(4);
    t_leds = k_malloc(sizeof(Task));
    Task *t_buttons __aligned(4);
    t_buttons = k_malloc(sizeof(Task));
    if (!t_leds || !t_buttons) {
        LOG_ERR("Failed to allocate memory for tasks\n");
        return -1;
    }

    Create_Task(t_leds, 100, 6, "leds_task", thread_leds);
    Create_Task(t_buttons, 100, 7, "buttons_task", thread_buttons);

    STBS_AddTask(scheduler, t_leds);
    STBS_AddTask(scheduler, t_buttons);

    STBS_Start(scheduler);
    
    LOG_INF("System is running\n");

    k_msleep(100000);

    return 0;
}